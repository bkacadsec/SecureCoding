#!/usr/bin/env bash

cd ..
docker-compose rm -f
docker-compose up
