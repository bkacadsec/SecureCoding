# WebGoat landing page

This serves the Github pages for the landing page of WebGoat.

# Running locally

```
docker run -t --rm -v "$PWD":/usr/src/app -p "4000:4000" starefossen/github-pages
```

And then browse to http://localhost:4000/docs

# Thanks to

[Freelancer](http://startbootstrap.com/template-overviews/freelancer/) is a one page freelancer portfolio theme for [Bootstrap](http://getbootstrap.com/) created by [Start Bootstrap](http://startbootstrap.com/). This theme features several content sections, a responsive portfolio grid with hover effects, full page portfolio item modals, and a working PHP contact form.

## Copyright and License

Copyright 2013-2018 Blackrock Digital LLC. Code released under the [MIT](https://github.com/BlackrockDigital/startbootstrap-freelancer/blob/gh-pages/LICENSE) license.

