CREATE TABLE jwt_keys(
  id varchar(20),
  key varchar(20)
);

INSERT INTO jwt_keys VALUES ('webgoat_key', 'qwertyqwerty1234');
INSERT INTO jwt_keys VALUES ('webwolf_key', 'doesnotreallymatter');
